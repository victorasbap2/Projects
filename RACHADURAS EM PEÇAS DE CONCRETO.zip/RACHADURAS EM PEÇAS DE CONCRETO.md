# 🚧 RACHADURAS EM PEÇAS DE CONCRETO 

**BIBLIOTECAS**


```python
import os
import matplotlib.pyplot as plt
import tensorflow as tf
from pathlib import Path
```

**DIRETÓRIOS**


```python
dataset_train_dir = Path(r'C:\Users\e109513\OneDrive - Tokio Marine Seguradora S A\Área de Trabalho\Concreto\Treino')
dataset_validation_dir = Path(r'C:\Users\e109513\OneDrive - Tokio Marine Seguradora S A\Área de Trabalho\Concreto\Validação')

dataset_train_normal = len(os.listdir(r'C:\Users\e109513\OneDrive - Tokio Marine Seguradora S A\Área de Trabalho\Concreto\Treino\Normal'))
dataset_train_rachadura = len(os.listdir(r'C:\Users\e109513\OneDrive - Tokio Marine Seguradora S A\Área de Trabalho\Concreto\Treino\Rachadura'))

dataset_validation_normal = len(os.listdir(r'C:\Users\e109513\OneDrive - Tokio Marine Seguradora S A\Área de Trabalho\Concreto\Validação\Normal'))
dataset_validation_rachadura = len(os.listdir(r'C:\Users\e109513\OneDrive - Tokio Marine Seguradora S A\Área de Trabalho\Concreto\Validação\Rachadura'))

print('Train Normal: %s' % dataset_train_normal)
print('Train Rachadura: %s' % dataset_train_rachadura)

print('\nValidation Normal: %s' % dataset_validation_normal)
print('Validation Rachadura: %s' % dataset_validation_rachadura)
```

    Train Normal: 10000
    Train Rachadura: 10000
    
    Validation Normal: 10000
    Validation Rachadura: 10000
    

**PRÉ-PROCESSAMENTO DE IMAGENS**


```python
image_width = 160
image_height = 160
image_color_channel = 3
image_color_channel_size = 255
image_size = (image_width, image_height)
image_shape = image_size + (image_color_channel,)

batch_size = 32
epochs = 10
learning_rate = 0.0001

class_names = ['normal', 'rachadura'] #array de saída
```

**DATASET DE TREINAMENTO**


```python
dataset_train = tf.keras.preprocessing.image_dataset_from_directory(
    dataset_train_dir,
    image_size = image_size,
    batch_size = batch_size,
    shuffle = True
)
```

    Found 20000 files belonging to 2 classes.
    

**DATASET DE VALIDAÇÃO**


```python
dataset_validation = tf.keras.preprocessing.image_dataset_from_directory(
    dataset_validation_dir,
    image_size = image_size,
    batch_size = batch_size,
    shuffle = True
)
```

    Found 20000 files belonging to 2 classes.
    

**DATASET DE TESTE** - Criado a partir do DATASET DE VALIDAÇÃO


```python
dataset_validation_cardinality = tf.data.experimental.cardinality(dataset_validation)
dataset_validation_batches = dataset_validation_cardinality // 5

dataset_test = dataset_validation.take(dataset_validation_batches)
dataset_validation = dataset_validation.skip(dataset_validation_batches)

print('Validation Dataset Cardinality: %d' % tf.data.experimental.cardinality(dataset_validation))
print('Test Dataset Cardinality: %d' % tf.data.experimental.cardinality(dataset_test))
```

    Validation Dataset Cardinality: 500
    Test Dataset Cardinality: 125
    


```python
autotune = tf.data.AUTOTUNE

dataset_train = dataset_train.prefetch(buffer_size = autotune)
dataset_validation = dataset_validation.prefetch(buffer_size = autotune)
dataset_test = dataset_validation.prefetch(buffer_size = autotune)
#Obs.
```


```python
def plot_dataset(dataset):

    plt.gcf().clear()
    plt.figure(figsize = (5, 5))

    for features, labels in dataset.take(1):

        for i in range(9):

            plt.subplot(3, 3, i + 1)
            plt.axis('off')

            plt.imshow(features[i].numpy().astype('uint8'))
            plt.title(class_names[labels[i]])
```

**PLOTAR DATASET DE TREINAMENTO**


```python
plot_dataset(dataset_train)
```


    <Figure size 640x480 with 0 Axes>



    
![png](output_16_1.png)
    


**PLOTAR DATASET DE VALIDAÇÃO**


```python
plot_dataset(dataset_validation)
```


    <Figure size 640x480 with 0 Axes>



    
![png](output_18_1.png)
    


## MODELO DE CLASSIFICAÇÃO


```python
model = tf.keras.models.Sequential([
    tf.keras.layers.experimental.preprocessing.Rescaling(
        1. / image_color_channel_size,
        input_shape = image_shape
    ), 
    tf.keras.layers.Conv2D(16, 3, padding = 'same', activation = 'relu'), #camada covolucional de tamanho 16 e Kernel 3x3 
    tf.keras.layers.MaxPooling2D(),
    tf.keras.layers.Conv2D(32, 3, padding = 'same', activation = 'relu'), #camada covolucional de tamanho 32 e Kernel 3x3
    tf.keras.layers.MaxPooling2D(),
    tf.keras.layers.Conv2D(64, 3, padding = 'same', activation = 'relu'), #camada covolucional de tamanho 64 e Kernel 3x3
    tf.keras.layers.MaxPooling2D(),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(128, activation = 'relu'), #camada com 128 nós
    tf.keras.layers.Dense(1, activation = 'sigmoid') #sigmoid retorna valores entre -1 e 1
])

model.compile(
    optimizer = tf.keras.optimizers.Adam(learning_rate = learning_rate),
    loss = tf.keras.losses.BinaryCrossentropy(),
    metrics = ['accuracy']
)

model.summary()
```

    Model: "sequential"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     rescaling (Rescaling)       (None, 160, 160, 3)       0         
                                                                     
     conv2d (Conv2D)             (None, 160, 160, 16)      448       
                                                                     
     max_pooling2d (MaxPooling2D  (None, 80, 80, 16)       0         
     )                                                               
                                                                     
     conv2d_1 (Conv2D)           (None, 80, 80, 32)        4640      
                                                                     
     max_pooling2d_1 (MaxPooling  (None, 40, 40, 32)       0         
     2D)                                                             
                                                                     
     conv2d_2 (Conv2D)           (None, 40, 40, 64)        18496     
                                                                     
     max_pooling2d_2 (MaxPooling  (None, 20, 20, 64)       0         
     2D)                                                             
                                                                     
     flatten (Flatten)           (None, 25600)             0         
                                                                     
     dense (Dense)               (None, 128)               3276928   
                                                                     
     dense_1 (Dense)             (None, 1)                 129       
                                                                     
    =================================================================
    Total params: 3,300,641
    Trainable params: 3,300,641
    Non-trainable params: 0
    _________________________________________________________________
    

**TREINAMENTO**


```python
history = model.fit(
    dataset_train,
    validation_data = dataset_validation,
    epochs = epochs
)
```

    Epoch 1/10
    625/625 [==============================] - 550s 875ms/step - loss: 0.1621 - accuracy: 0.9368 - val_loss: 0.0670 - val_accuracy: 0.9822
    Epoch 2/10
    625/625 [==============================] - 524s 836ms/step - loss: 0.0518 - accuracy: 0.9837 - val_loss: 0.0567 - val_accuracy: 0.9859
    Epoch 3/10
    625/625 [==============================] - 505s 807ms/step - loss: 0.0401 - accuracy: 0.9872 - val_loss: 0.0430 - val_accuracy: 0.9874
    Epoch 4/10
    625/625 [==============================] - 366s 583ms/step - loss: 0.0332 - accuracy: 0.9902 - val_loss: 0.0372 - val_accuracy: 0.9879
    Epoch 5/10
    625/625 [==============================] - 298s 477ms/step - loss: 0.0265 - accuracy: 0.9920 - val_loss: 0.0328 - val_accuracy: 0.9893
    Epoch 6/10
    625/625 [==============================] - 298s 476ms/step - loss: 0.0206 - accuracy: 0.9939 - val_loss: 0.0291 - val_accuracy: 0.9916
    Epoch 7/10
    625/625 [==============================] - 393s 630ms/step - loss: 0.0166 - accuracy: 0.9953 - val_loss: 0.0253 - val_accuracy: 0.9928
    Epoch 8/10
    625/625 [==============================] - 398s 635ms/step - loss: 0.0134 - accuracy: 0.9961 - val_loss: 0.0247 - val_accuracy: 0.9924
    Epoch 9/10
    625/625 [==============================] - 319s 510ms/step - loss: 0.0115 - accuracy: 0.9969 - val_loss: 0.0239 - val_accuracy: 0.9931
    Epoch 10/10
    625/625 [==============================] - 334s 535ms/step - loss: 0.0104 - accuracy: 0.9968 - val_loss: 0.0209 - val_accuracy: 0.9933
    

**TESTE**


```python
def plot_dataset_predictions(dataset):
    features, labels = dataset.as_numpy_iterator().next()
    predictions = model.predict_on_batch(features).flatten()
    predictions = tf.where(predictions < 0.5, 0, 1)
    
    print('Labels:   %s' % labels)
    print('Predictions: %s' %predictions.numpy())
    
    plt.gcf().clear()
    plt.figure(figsize = (5,5))
    
    for i in range (9):
        plt.subplot(3,3, i + 1)
        plt.axis('off')
        
        plt.imshow(features[i].astype('uint8'))
        plt.title(class_names[predictions[i]])
```


```python
plot_dataset_predictions(dataset_test)
```

    Labels:   [1 0 1 0 1 1 0 1 1 0 0 0 0 0 0 0 0 1 0 0 1 1 0 0 1 1 1 0 1 1 0 1]
    Predictions: [1 0 1 0 1 1 0 1 1 0 0 0 0 0 0 0 0 1 0 0 1 1 0 0 1 1 1 0 1 1 0 1]
    


    <Figure size 640x480 with 0 Axes>



    
![png](output_25_2.png)
    


**RESULTADOS**


```python
def plot_model():
    accuracy = history.history['accuracy']
    val_accuracy = history.history['val_accuracy']
    
    loss = history.history['loss']
    val_loss = history.history['val_loss']
    
    epochs_range = range(epochs)
    
    plt.gcf().clear()
    plt.figure(figsize = (10,5))
    
    plt.subplot(1, 2, 1)
    plt.title('ACURACIA DE TREINO E VALIDACAO')
    plt.plot(epochs_range, accuracy, label = 'Acuracia de Treinamento', color = 'blue')
    plt.plot(epochs_range, val_accuracy, label = 'Acuracia de Validacao', color='magenta')
    #plt.xlabel("Epochs")
    #plt.ylabel("Acuracia")
    
    plt.legend(loc = 'lower right')
    
    plt.subplot(1,2,2)
    plt.title('LOSS DE TREINO E VALIDACAO')
    plt.plot(epochs_range, loss, label = 'Loss de Treinamento', color='blue')
    plt.plot(epochs_range, val_loss, label = 'Loss de Validacao', color='magenta')
    #plt.xlabel("Epochs")
    #plt.ylabel("Acuracia")
    plt.legend(loc = 'upper right')
    
    plt.show()
```


```python
plot_model()
```


    <Figure size 640x480 with 0 Axes>



    
![png](output_28_1.png)
    



```python
import plotly.express as px
import numpy as np
import seaborn as sns
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.pipeline import make_pipeline
from sklearn.metrics import ConfusionMatrixDisplay
```


```python
fig = px.line(
    history.history,
    y=['loss', 'val_loss'],
    labels={'index': "Epoch", 'value': "Loss"},
    title="Loss de Treinamento e Loss de Validação X Epoch"
)

fig.show()
```


<div>                            <div id="b9f1254e-3284-4053-97a6-908c569fabdc" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("b9f1254e-3284-4053-97a6-908c569fabdc")) {                    Plotly.newPlot(                        "b9f1254e-3284-4053-97a6-908c569fabdc",                        [{"hovertemplate":"variable=loss<br>Epoch=%{x}<br>Loss=%{y}<extra></extra>","legendgroup":"loss","line":{"color":"#636efa","dash":"solid"},"marker":{"symbol":"circle"},"mode":"lines","name":"loss","orientation":"v","showlegend":true,"x":[0,1,2,3,4,5,6,7,8,9],"xaxis":"x","y":[0.16206896305084229,0.051772650331258774,0.040146354585886,0.033175572752952576,0.026542237028479576,0.020568497478961945,0.016589686274528503,0.013439830392599106,0.011527289636433125,0.0103849396109581],"yaxis":"y","type":"scatter"},{"hovertemplate":"variable=val_loss<br>Epoch=%{x}<br>Loss=%{y}<extra></extra>","legendgroup":"val_loss","line":{"color":"#EF553B","dash":"solid"},"marker":{"symbol":"circle"},"mode":"lines","name":"val_loss","orientation":"v","showlegend":true,"x":[0,1,2,3,4,5,6,7,8,9],"xaxis":"x","y":[0.0669897198677063,0.05666206032037735,0.043030381202697754,0.037202052772045135,0.032846152782440186,0.02908167615532875,0.02527996152639389,0.0246737040579319,0.023930994793772697,0.020907048135995865],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"Epoch"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"Loss"}},"legend":{"title":{"text":"variable"},"tracegroupgap":0},"title":{"text":"Loss de Treinamento e Loss de Valida\u00e7\u00e3o X Epoch"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('b9f1254e-3284-4053-97a6-908c569fabdc');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
#Precision = metrics.precision_score(actual, predicted)
#Sensitivity_recall = metrics.recall_score(actual, predicted)
#F1_score = metrics.f1_score(actual, predicted)

#print("Precisao: {:.5f}".format(Precision*100))
#print("Recall: {:.5f}".format(Sensitivity_recall*100))
#print("F1-Score: {:.5f}".format(F1_score*100))
```


```python
def evaluate_model(model, dataset_test):
    
    results = model.evaluate(dataset_test, verbose=0)
    loss = results[0]
    acc = results[1]
    
    print("    Test Loss: {:.5f}".format(loss))
    print("Test Accuracy: {:.2f}%".format(acc * 100))
```


```python
evaluate_model(model, dataset_test)
```

        Test Loss: 0.02075
    Test Accuracy: 99.33%
    
